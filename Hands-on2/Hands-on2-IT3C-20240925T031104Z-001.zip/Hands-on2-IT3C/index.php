<?php
    //echo "name";
    # echo "address";
    /* 
    
    */ 

    echo "Hello "."Ace "."Matamis</h1>";
    $firstname = "Ace";
    $lastname = "MAtamis";
    echo "</h1> Hello" .$firstname. " " .$lastname . "</h1>";

    $x = 10;
    $y = 99.9;
    $z = $x*$y;
    
    echo $z;

?>