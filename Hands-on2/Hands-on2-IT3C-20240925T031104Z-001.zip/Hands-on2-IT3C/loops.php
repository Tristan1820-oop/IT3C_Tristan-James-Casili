<h1> Loops </h1>

<?php
    $i = 1;
    while ($i < 6){
        echo $i;
        $i++;

    }

    $a = 1;
    do{
        echo $a;
        $a++;
    }
    while ($a < 6);

    echo '<br/>';
    $colors = array("red","green","blue","yellow");
    foreach($colors as $color){
        echo
    }

    

?>